__all__ = ['VERSION']

VERSION = '7.6.0'
SAVE_PATH = '~/.spotifydl'
